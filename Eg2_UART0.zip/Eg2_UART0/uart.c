/*
 * uart.c
 *
 *  Created on: Feb 26, 2015
 *      Author: Edu_win7
 */

#include "uart.h"


/***************************************************************************
                                UART0 Functions
******************************************************************************/
/** This Program initialize the UART0 **/
void Uart0_Init(unsigned long BaudRate)
{
	unsigned int CountVal;
	VPBDIV = 0X01;  						                	// to choose pclk=cclk

	PINSEL0 &= ~0x0F;  	// Clearing GPIO Values for Pin0.0 and P0.1 to config it for UART0
	PINSEL0 |= 0x05;   	// Configure P0.0 and P0.1 for UART0 TxD and RxD
    IO0DIR &= ~0x02;   	// Direction: P0.1 RX as input
    IO0DIR |= 0x01;    	// Direction: P0.0 TX as Output

	U0FCR = 0X07;		// Reset FIFO and Enable it

	U0LCR |= 0x03;		// databits: 8, parity: No, stopbit: 1

	CountVal = FOSC /(16 * BaudRate);   // Pg.150 LPC2148 User Manual (Rev. 4.0 2012 Edition)
	U0LCR |= (0x01<<7);   				// Divisor latch enable for setting of Fractoinal divisor value

	U0DLL = (CountVal & 0XFF); 			// Store DLL
	U0DLM = ((CountVal >> 8) & 0XFF);	// Store DLM

	if(BaudRate >=115200 && BaudRate < 460800 )
	{
		U0FDR |= (1<<0);   // DIVADDVAL = 1
		U0FDR |= (12<<4);  // MULVAL = 12
	}

	U0LCR &= ~(0x01<<7);
	U0TER |= (1<<7);		// UART0 Enable
}

/** This Function is used to transmit data using UART0 **/
void Uart0_Tx(char Data)
{
	while(!(U0LSR & 0x20));	// Wait until UART0 FIFO gets empty
	U0THR = Data;			// Transmit data using Transmit holding register
}

/** This Function is used to transmit string using UART0 **/
void Uart0_String(char *Data)
{
	while(*Data)			// While until string gets complete
    	Uart0_Tx(*Data++);	// UART0 Transmit character function
}

/** This Function is used to Receive data using UART0 **/
char Uart0_Rx(void)
{
    char Data;

	while(!(U0LSR & 0x01));	// Wait for Single character in Receive FIFO
	Data = U0RBR;			// Receive character from Receive holding register to local variable
	return(Data);			// Return Received character
}
