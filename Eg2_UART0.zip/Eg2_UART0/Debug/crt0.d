crt0.d crt0.o: ../crt0.S
