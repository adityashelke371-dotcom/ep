main.d main.o: ../main.c ../lpc214x.h ../uart.h

../lpc214x.h:

../uart.h:
