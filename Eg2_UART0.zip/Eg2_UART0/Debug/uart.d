uart.d uart.o: ../uart.c ../uart.h ../lpc214x.h

../uart.h:

../lpc214x.h:
