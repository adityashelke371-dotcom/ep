/*
 * uart.h
 *
 *  Created on: Feb 26, 2015
 *      Author: Edu_win7
 */

#ifndef UART_H_
#define UART_H_

#include "lpc214x.h"

#define FOSC	12000000



/* Function Declaration */
void Uart0_Init(unsigned long BaudRate);
void Uart0_Tx(char Data);
void Uart0_String(char *Data);
char Uart0_Rx(void);

#endif /* UART_H_ */
