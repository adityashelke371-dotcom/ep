/**  This Program is used to display a character and string.
 *   This program also echo the character typed from the HyperTerminal/Teraterm
 */

#include "lpc214x.h"
#include "uart.h"


/* Main Program */
int main(void)
{
	char rdata;
	Uart0_Init(9600);						// UART0 initialized with Baudrate=9600

	Uart0_Tx('A');							// Transmit single character using UART0
	Uart0_String(" UART0 Demo Program \n\r");// Transmit String using UART0
	Uart0_String(" \n\r");					// Transmit String using UART0
	Uart0_String(" Type any Character on HyperTerminal or Teraterm \n\r");// Transmit String using UART0

	while(1)
	{
		rdata = Uart0_Rx();					// Receive character from UART0 input from HyperTerminal or Teraterm
		Uart0_Tx(rdata);					// Transmit the same character received from HyperTerminal or Teraterm
	}
}


