/*
 * adc.h
 *
 *  Created on: Feb 26, 2015
 *      Author: Edu_win7
 */

#ifndef ADC_H_
#define ADC_H_

#include "lpc214x.h"
#include "VIClowlevel.h"


/* Function Declaration for ADC*/
void Adc_Init(void);
void Read_Adc(unsigned int *Value);


#endif /* ADC_H_ */
