adc.d adc.o: ../adc.c ../adc.h ../lpc214x.h ../VIClowlevel.h

../adc.h:

../lpc214x.h:

../VIClowlevel.h:
