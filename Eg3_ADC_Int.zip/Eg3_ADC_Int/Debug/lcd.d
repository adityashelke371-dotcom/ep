lcd.d lcd.o: ../lcd.c ../lcd.h ../lpc214x.h

../lcd.h:

../lpc214x.h:
