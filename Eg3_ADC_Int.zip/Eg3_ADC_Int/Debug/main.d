main.d main.o: ../main.c ../lpc214x.h ../VIClowlevel.h ../lcd.h ../adc.h

../lpc214x.h:

../VIClowlevel.h:

../lcd.h:

../adc.h:
