/**
 *  This Program is used to display ADC value on LCD
 *  Here ADC0.1 is used with External interrupt as trigger
 */
#include "lpc214x.h"
#include "VIClowlevel.h"
#include "lcd.h"
#include "adc.h"

unsigned int AdcData =0;

// Function Declaration
void Exti_Init(void);

/* Interrupt Handler */
void ext1isr(void)
{
	ISR_ENTRY();

	Read_Adc(&AdcData);			  // Read ADC value and store in global variable
    DisplayHexLcd(AdcData);       // Display value stored in global variable on LCD
    Delay(80000);				  // Some Delay

	EXTINT=0XC0;				  // Clear Interrupt flag
	VICVectAddr = 0x00;           // Reset vector address

	ISR_EXIT();
}

/* Main Program */
int main(void)
{
	Lcd_Init();
	Adc_Init();
	Lcd_Cmd(0x01);					// LCD clear cmd
	Exti_Init();					// Initialize External Interrupt

	Lcd_Cmd(0x80);					// LCD first line cmd
	Lcd_String("ADC Value ");		// msg string
	Lcd_Cmd(0xC0);					// LCD second line cmd
	Lcd_String("CH0.1:");			// msg string

	enableIRQ();					// Global ISR

	while(1);
}


/* Configure External Interrupt */
void Exti_Init(void)
{
	/* Config External Interrupt */
	IO0DIR |= 0x02;					// Set Pin 0.1 direction as output for external interrupt
	IO0SET |= 0x02;					// Set Pin 0.1 to High for external interrupt
	PINSEL0 |= (1<<2)|(1<<3);		// Configure GPIO P0.1 as External interrupt
	EXTMODE = 1;  					// Mode : Level Trigger for interrupt
	EXTPOLAR = 0;  					// Interrupt Polarity: High to Low
	VICIntEnable |= (0x01 << 14);	// Enable external interrupt
	VICIntSelect &= (~(0x01 << 14));// Select external interrupt
	VICVectAddr0 = (unsigned)ext1isr;	// Provide External interrupt handler address
	VICVectCntl0 = (0x20|14);
}




