/*
 * lcd.h
 *
 *  Created on: Feb 26, 2015
 *      Author: Edu_win7
 */

#ifndef LCD_H_
#define LCD_H_

#include "lpc214x.h"

/* Macro Definitions */
#define SET(x) (1<<x)
#define CLR(X) (0<<X)
#define CRYSTAL_FREQUENCY_IN_HZ	11059200
#define PLL_MULTIPLIER	1

// Macros (as arguments) for the Delay() function
#define DELAY_15MS	CRYSTAL_FREQUENCY_IN_HZ*PLL_MULTIPLIER/2304
#define DELAY_6MS	CRYSTAL_FREQUENCY_IN_HZ*PLL_MULTIPLIER/5760
#define DELAY_250US	CRYSTAL_FREQUENCY_IN_HZ*PLL_MULTIPLIER/138240
#define DELAY_TINY	CRYSTAL_FREQUENCY_IN_HZ*PLL_MULTIPLIER/11059200

/* Function Declaration */
void Delay(unsigned loops);
void Toggle_En(void);
void Lcd_Init(void);
void Lcd_Cmd(char lcdcmd);
void Lcd_Data(char lcddata);
void Lcd_String(char *string);
void DisplayHexLcd(int LcdData);

#endif /* LCD_H_ */
