/*
 * adc.c
 *
 *  Created on: Feb 26, 2015
 *      Author: Edu_win7
 */

#include "adc.h"


/***************************************************************************
                                ADC Functions
******************************************************************************/

/** This function is used to Initialize ADC channel ADC0.1 **/
void Adc_Init(void)
{
	PINSEL1 |= 0x01000000;	// configure GPIO pin as ADC0.1
	VPBDIV = 1;             // PCLK = FOSC
	AD0CR = 0x00200302;		// AD0.1 Enable, PDN =1, PClk/4
}


/* This function is used to read ADC channel ADC0.1 **/
void Read_Adc(unsigned int *Value)
{
	AD0CR |= 0x01000000;	// Start ADC Channel Conversion

	while((AD0GDR & 0x80000000)!=0x80000000); // Check for ADC Conversion to Complete; Check Done bit
	*Value = (AD0GDR & 0x0000FFC0)>>6;        // store value in pointer variable; ADC value starts from [6:15]
}



